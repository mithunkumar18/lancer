for (let count=10;count>=0;count--)
{
    console.log(count)}
    